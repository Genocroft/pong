// Find needed objects.

const player = document.querySelector('.player');
const enemy = document.querySelector('.enemy');
const ball = document.querySelector('.ball');

// Variables for  player, enemy and ball. Used later for movement.

let playerY = window.innerHeight / 2 - player.offsetHeight / 2; 
let enemyY = window.innerHeight / 2 - enemy.offsetHeight / 2; 
let ballX = window.innerWidth / 2 - ball.offsetWidth / 2;
let ballY = window.innerHeight / 2 - ball.offsetHeight / 2;

// Variable speed of the ball horizontal and vertical.

let ballspeedX = 5;
let ballspeedY = 5;


// Allows player to move up and down.

function movePlayer(i) {
    playerY = i.clientY - player.offsetHeight / 2;
    if (playerY < 0) playerY = 0;
    if (playerY + player.offsetHeight > window.innerHeight) playerY = window.innerHeight - player.offsetHeight;
    player.style.top = playerY + 'px';
}

// Allows enemy to move up and down.

function moveEnemy() {
    const enemyCenter = enemyY + enemy.offsetHeight / 2;
    if (enemyCenter < ballY) {
        enemyY += 2.5;
    } else {
        enemyY -= 2.5;
    }
    if (enemyY <0) enemyY = 0;
    if (enemyY + enemy.offsetHeight > window.innerHeight) enemyY = window.innerHeight - enemy.offsetHeight;
    enemy.style.top = enemyY + 'px';
}

// Uses previous mentioned variables to give ball proper movement.

function moveBall() {
    ballX += ballspeedX;
    ballY += ballspeedY;

// Ability to bounce off top and bottom.

if (ballY <= 0 || ballY + ball.offsetHeight >= window.innerHeight) {
    ballspeedY = -ballspeedY;
}

if (
    ballX <= player.offsetLeft + player.offsetWidth &&
    ballY + ball.offsetHeight >= playerY &&
    ballY <= playerY + player.offsetHeight
) {
    ballspeedX = -ballspeedX;
}

if (
    ballX + ball.offsetWidth >= enemy.offsetLeft &&
    ballY + ball.offsetHeight >= enemyY &&
    ballY <= enemyY + enemy.offsetHeight
) {
    ballspeedX = -ballspeedX;
}

// If ball somehow goes out of screen make it reappear again.

if (ballX < 0 || ballX + ball.offsetWidth > window.innerWidth) {
    ballX = window.innerWidth / 2 - ball.offsetWidth / 2;
    ballY = window.innerHeight / 2 - ball.offsetHeight / 2;
    ballspeedX = -ballspeedX;
}

ball.style.left = ballX + 'px';
ball.style.top = ballY + 'px';

}

// Have everything loop and use the mouse to move.
window.addEventListener('mousemove', movePlayer);

function gameLoop() {
    moveEnemy();
    moveBall();
    requestAnimationFrame(gameLoop);
}

gameLoop();
